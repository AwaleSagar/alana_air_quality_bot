## happy path
* greet
  - utter_greet
* mood_great
  - utter_happy

## say goodbye
* goodbye
  - utter_goodbye

## today air
* air_quality_today
  - utter_today_air
  
* air_quality_historical
  - utter_historical_air
  
* air_quality_forecast
  - utter_forecast_air
